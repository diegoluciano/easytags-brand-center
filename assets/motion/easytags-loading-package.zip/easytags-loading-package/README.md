# EasyTags Loading Animation Package

Este pacote contém tudo para implementar a animação de loading do logo EasyTags.

## Arquivos

- `easytags-loading.svg` → SVG animado com classes do logo
- `easytags-loading.css` → keyframes e regras de animação
- `index.html` → exemplo funcional de uso

## Implementação rápida

### Opção 1: usar SVG direto

Copie os 2 arquivos para o sistema:

- `easytags-loading.svg`
- `easytags-loading.css`

O SVG já referencia o CSS via `xml-stylesheet`.

### Opção 2: usar inline no HTML (mais controle)

1. Cole o conteúdo do `easytags-loading.svg` no HTML.
2. Inclua `easytags-loading.css` na página.

## Personalização

No CSS, você pode ajustar:

- `--easytags-green`
- `--easytags-duration`

## Compatibilidade

Recomendado para uso web moderno (Chrome, Edge, Safari, Firefox).
